@extends("app")
@section("content")
 
@include("_particles.sub_header") 

 <div class="container margin_60">



  <div class="row">
    <div class="col-md-3">

    </div>  
    <div class="col-md-6">
         <div class="main_title">
      		<h1 style="font-size: 128px;font-weight: 800;">404!</h4>      
    	</div>
      </div>
      <!-- End col-md-6 -->


     
        
  </div>
  <!-- End row -->   


   
</div>  

@endsection
